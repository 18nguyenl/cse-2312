#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

extern void uint32ToBinary(char str[], uint32_t x);
extern void int32ToBinary(char str[], int32_t x);

int main(void) {

	uint32_t x;
	int32_t y;
	char str[33];

	printf("Input unsigned int: ");
	scanf("%u", &x);

	uint32ToBinary(str, x);

	printf("%d = %s\n", x, str);

	printf("Input signed int: ");
	scanf("%d", &y);

	int32ToBinary(str, y);

	printf("%d = %s\n", y, str);

	return EXIT_SUCCESS;
}
